<?php

namespace App\Services;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use App\Models\Setting;
use App\Models\User;
use App\Models\Transaction;
use App\Models\WalletFunding;
use App\Models\UserCard;
use Exception;

class PaystackService
{
    protected $secretKey;
    protected $publicKey;
    protected $baseUrl;

    public function __construct()
    {
        $this->secretKey = config('services.paystack.secret_key') ?? Setting::where('key', 'paystack_secret_key')->value('value');
        $this->publicKey = config('services.paystack.public_key') ?? Setting::where('key', 'paystack_public_key')->value('value');
        $this->baseUrl = 'https://api.paystack.co';
    }

    /**
     * Initialize payment transaction
     */
    public function initializeTransaction($amount, $email, $reference, $callbackUrl, $metadata = [])
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->secretKey,
                'Accept' => 'application/json',
            ])->post($this->baseUrl . '/transaction/initialize', [
                'amount' => $amount * 100, // Paystack amount is in kobo
                'email' => $email,
                'reference' => $reference,
                'callback_url' => $callbackUrl,
                'metadata' => $metadata,
            ]);

            if ($response->successful()) {
                return [
                    'success' => true,
                    'data' => $response->json()['data'] ?? [],
                    'message' => 'Transaction initialized successfully',
                ];
            }

            Log::error('Paystack API Error: Failed to initialize transaction', [
                'response' => $response->json(),
            ]);

            return [
                'success' => false,
                'message' => $response->json()['message'] ?? 'Failed to initialize transaction',
            ];
        } catch (Exception $e) {
            Log::error('Paystack API Error: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'An error occurred while connecting to the payment gateway',
            ];
        }
    }

    /**
     * Verify transaction status
     */
    public function verifyTransaction($reference)
    {
        try {
            // disable ssl verification for this url or requested URL
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->secretKey,
                'Accept' => 'application/json',
                'verify' => false, // Disable SSL verification for this request only
            ])->get($this->baseUrl . '/transaction/verify/' . $reference);

            if ($response->successful()) {
                $data = $response->json()['data'] ?? [];
                $status = $data['status'] ?? '';

                return [
                    'success' => true,
                    'data' => $data,
                    'status' => $this->mapPaymentStatus($status),
                ];
            }

            Log::error('Paystack API Error: Failed to verify transaction', [
                'response' => $response->json(),
            ]);

            return [
                'success' => false,
                'message' => $response->json()['message'] ?? 'Failed to verify transaction',
            ];
        } catch (Exception $e) {
            Log::error('Paystack API Error: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'An error occurred while connecting to the payment gateway',
            ];
        }
    }

    /**
     * Verify card details and get authorization code
     */
    public function verifyCard($authorizationCode, $email)
    {
        try {
            // First, verify the authorization
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->secretKey,
                'Accept' => 'application/json',
            ])->get($this->baseUrl . '/transaction/verify/' . $authorizationCode);

            if ($response->successful()) {
                $data = $response->json()['data'] ?? [];
                
                // Check if transaction was successful
                if ($data['status'] === 'success' && isset($data['authorization'])) {
                    $authorization = $data['authorization'];
                    
                    return [
                        'success' => true,
                        'data' => [
                            'authorization' => $authorization,
                            'card_type' => $authorization['card_type'] ?? 'unknown',
                            'last4' => $authorization['last4'] ?? '',
                            'exp_month' => $authorization['exp_month'] ?? '',
                            'exp_year' => $authorization['exp_year'] ?? '',
                            'bank' => $authorization['bank'] ?? 'Unknown Bank',
                            'reusable' => $authorization['reusable'] ?? false,
                        ],
                        'message' => 'Card verified successfully',
                    ];
                }
            }

            return [
                'success' => false,
                'message' => 'Card verification failed',
            ];
        } catch (Exception $e) {
            Log::error('Paystack Card Verification Error: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'An error occurred while verifying card',
            ];
        }
    }

    /**
     * Charge a saved card using authorization code
     */
    public function chargeAuthorization($authorizationCode, $amount, $email, $reason = 'Payment')
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->secretKey,
                'Accept' => 'application/json',
            ])->post($this->baseUrl . '/transaction/charge_authorization', [
                'authorization_code' => $authorizationCode,
                'email' => $email,
                'amount' => $amount * 100, // Convert to kobo
                'reference' => 'CHG_' . time() . '_' . uniqid(),
                'metadata' => [
                    'reason' => $reason,
                    'timestamp' => now()->toDateTimeString(),
                ],
            ]);

            if ($response->successful()) {
                $data = $response->json()['data'] ?? [];
                
                if ($data['status'] === 'success') {
                    return [
                        'success' => true,
                        'data' => $data,
                        'message' => 'Payment successful',
                    ];
                } else {
                    return [
                        'success' => false,
                        'message' => $data['gateway_response'] ?? 'Payment failed',
                        'data' => $data,
                    ];
                }
            }

            Log::error('Paystack Charge Authorization Error', [
                'response' => $response->json(),
            ]);

            return [
                'success' => false,
                'message' => $response->json()['message'] ?? 'Failed to charge card',
            ];
        } catch (Exception $e) {
            Log::error('Paystack Charge Authorization Error: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'An error occurred while charging card',
            ];
        }
    }

    /**
     * Get list of transactions for a customer
     */
    public function getCustomerTransactions($customerCode)
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->secretKey,
                'Accept' => 'application/json',
            ])->get($this->baseUrl . '/transaction', [
                'customer' => $customerCode,
            ]);

            if ($response->successful()) {
                return [
                    'success' => true,
                    'data' => $response->json()['data'] ?? [],
                ];
            }

            return [
                'success' => false,
                'message' => 'Failed to fetch transactions',
            ];
        } catch (Exception $e) {
            Log::error('Paystack Error: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'An error occurred',
            ];
        }
    }

    /**
     * Create a customer on Paystack
     */
    public function createCustomer(User $user)
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->secretKey,
                'Accept' => 'application/json',
            ])->post($this->baseUrl . '/customer', [
                'email' => $user->email,
                'first_name' => explode(' ', $user->name)[0] ?? $user->name,
                'last_name' => explode(' ', $user->name)[1] ?? '',
                'phone' => $user->phone_number,
            ]);

            if ($response->successful()) {
                return [
                    'success' => true,
                    'data' => $response->json()['data'] ?? [],
                ];
            }

            return [
                'success' => false,
                'message' => 'Failed to create customer',
            ];
        } catch (Exception $e) {
            Log::error('Paystack Error: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'An error occurred',
            ];
        }
    }

    /**
     * Create a dedicated virtual account for a user
     */
    public function createDedicatedAccount(User $user)
    {
        try {
            // First, ensure the user is a customer on Paystack
            $customerResponse = $this->createCustomer($user);
            if (!$customerResponse['success']) {
                return $customerResponse;
            }

            $customerCode = $customerResponse['data']['customer_code'];

            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->secretKey,
                'Accept' => 'application/json',
            ])->withoutVerifying()->post($this->baseUrl . '/dedicated_account', [
                'customer' => $customerCode,
            ]);

            if ($response->successful()) {
                return [
                    'success' => true,
                    'data' => $response->json()['data'] ?? [],
                ];
            }

            Log::error('Paystack API Error: Failed to create dedicated account', [
                'response' => $response->json(),
            ]);

            return [
                'success' => false,
                'message' => $response->json()['message'] ?? 'Failed to create dedicated account',
            ];
        } catch (Exception $e) {
            Log::error('Paystack API Error: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'An error occurred while connecting to the payment gateway',
            ];
        }
    }

    /**
     * Map Paystack payment status to application status
     */
    protected function mapPaymentStatus($paystackStatus)
    {
        switch ($paystackStatus) {
            case 'success':
                return 'successful';
            case 'pending':
                return 'pending';
            case 'failed':
                return 'failed';
            default:
                return 'pending';
        }
    }

    /**
     * Process webhook notification from Paystack
     */
    public function processWebhook($payload)
    {
        try {
            $event = $payload['event'] ?? '';
            $data = $payload['data'] ?? [];

            switch ($event) {
                case 'charge.success':
                    return $this->processSuccessfulCharge($data);
                case 'transfer.success':
                    return $this->processSuccessfulTransfer($data);
                case 'subscription.create':
                    return $this->processSubscriptionCreate($data);
                default:
                    Log::info('Unhandled Paystack Webhook Event: ' . $event, $data);
                    return [
                        'success' => true,
                        'message' => 'Event type not handled: ' . $event,
                    ];
            }
        } catch (Exception $e) {
            Log::error('Paystack Webhook Error: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'An error occurred while processing webhook',
            ];
        }
    }

    /**
     * Process successful charge webhook
     */
    protected function processSuccessfulCharge($data)
    {
        $reference = $data['reference'] ?? '';
        $amount = ($data['amount'] ?? 0) / 100; // Convert from kobo to naira
        $status = $data['status'] ?? '';
        $authorization = $data['authorization'] ?? null;
        $channel = $data['channel'] ?? '';

        if (empty($reference) || $status !== 'success') {
            return [
                'success' => false,
                'message' => 'Invalid transaction data',
            ];
        }

        // Handle dedicated virtual account transactions
        if ($channel === 'dedicated_nuban') {
            return $this->processDedicatedAccountTransaction($amount, $data);
        }

        // Handle different transaction types
        if (str_starts_with($reference, 'BOR_')) {
            // Borrowing repayment
            return $this->processBorrowingRepayment($reference, $amount, $data);
        } elseif (str_starts_with($reference, 'CHG_')) {
            // Card charge
            return $this->processCardCharge($reference, $amount, $data);
        } else {
            // Wallet funding
            return $this->processWalletFunding($reference, $amount, $data);
        }
    }

    /**
     * Process wallet funding transaction with atomic safety
     */
    protected function processWalletFunding($reference, $amount, $data)
    {
        $lock = \Illuminate\Support\Facades\Cache::lock('paystack_webhook:' . $reference, 30);
        
        if (!$lock->get()) {
            return [
                'success' => false,
                'message' => 'Transaction is currently being processed by another worker',
            ];
        }

        try {
            return \Illuminate\Support\Facades\DB::transaction(function () use ($reference, $amount, $data) {
                $walletFunding = WalletFunding::where('reference', $reference)
                    ->lockForUpdate()
                    ->first();

                if (!$walletFunding) {
                    return [
                        'success' => false,
                        'message' => 'Wallet funding record not found',
                    ];
                }

                if ($walletFunding->status === 'successful') {
                    return [
                        'success' => true,
                        'message' => 'Transaction already processed',
                    ];
                }

                // Calculate fee based on new rules: 1.5% + 100 for 2000 and above
                $fee = ($amount * 1.5) / 100;
                if ($amount >= 2000) {
                    $fee += 100;
                }
                $netAmount = $amount - $fee;

                // Update wallet funding status
                $walletFunding->status = 'successful';
                $walletFunding->fee = $fee;
                $walletFunding->response_data = array_merge($walletFunding->response_data ?? [], [
                    'completed_at' => now(),
                    'payment_reference' => $data['id'] ?? '',
                    'payment_method' => 'paystack',
                    'payment_details' => $data,
                    'fee' => $fee,
                    'net_amount' => $netAmount,
                ]);
                $walletFunding->save();

                // Update transaction status
                $transaction = Transaction::where('reference', $reference)->lockForUpdate()->first();
                if ($transaction) {
                    $transaction->status = 'successful';
                    $transaction->fee = $fee;
                    $transaction->save();
                }

                // Credit user wallet with debt settlement
                $user = User::where('id', $walletFunding->user_id)->lockForUpdate()->first();
                if ($user) {
                    // Settle outstanding debts first
                    $borrowingService = app(\App\Services\BorrowingService::class);
                    $remainingAmount = $borrowingService->settleDebts($user, $netAmount);
                    
                    if ($remainingAmount < $netAmount) {
                        $settledAmount = $netAmount - $remainingAmount;
                        $notificationService = app(\App\Services\NotificationService::class);
                        $notificationService->sendSystemNotification(
                            $user,
                            'Debt Automatically Settled',
                            "₦{$settledAmount} has been deducted from your funding to settle your outstanding debt.",
                            'info'
                        );
                    }
                    
                    $user->wallet_balance += $remainingAmount;
                    $user->save();

                    // Process referral bonus
                    $referralService = app(\App\Services\ReferralService::class);
                    if ($transaction) {
                        $referralService->processReferralBonus($transaction);
                    }
                }

                return [
                    'success' => true,
                    'message' => 'Wallet funding processed successfully',
                ];
            });
        } catch (\Exception $e) {
            Log::error('Paystack processWalletFunding failed: ' . $e->getMessage(), [
                'reference' => $reference,
                'trace' => $e->getTraceAsString()
            ]);
            return [
                'success' => false,
                'message' => 'Internal error: ' . $e->getMessage(),
            ];
        } finally {
            $lock->release();
        }
    }

    /**
     * Process borrowing repayment
     */
    protected function processBorrowingRepayment($reference, $amount, $data)
    {
        // You'll need to implement this based on your borrowing system
        // This would update borrowing status and mark as paid
        
        Log::info('Borrowing repayment processed', [
            'reference' => $reference,
            'amount' => $amount,
            'data' => $data,
        ]);

        return [
            'success' => true,
            'message' => 'Borrowing repayment processed',
        ];
    }

    /**
     * Process dedicated virtual account transaction
     */
    protected function processDedicatedAccountTransaction($amount, $data)
    {
        $customer = $data['customer'] ?? [];
        $email = $customer['email'] ?? '';
        $reference = $data['reference'] ?? '';

        if (empty($email)) {
            return [
                'success' => false,
                'message' => 'Customer email not found in payload',
            ];
        }

        $lock = \Illuminate\Support\Facades\Cache::lock('paystack_virtual_acc:' . $reference, 30);
        
        if (!$lock->get()) {
            return [
                'success' => false,
                'message' => 'Transaction is currently being processed',
            ];
        }

        try {
            return \Illuminate\Support\Facades\DB::transaction(function () use ($email, $amount, $reference, $data) {
                $user = User::where('email', $email)->lockForUpdate()->first();

                if (!$user) {
                    return [
                        'success' => false,
                        'message' => 'User not found for email: ' . $email,
                    ];
                }

                // Check if transaction already exists and is successful
                $existingTransaction = Transaction::where('reference', $reference)->first();
                if ($existingTransaction && $existingTransaction->status === 'successful') {
                    return [
                        'success' => true,
                        'message' => 'Transaction already processed',
                    ];
                }

                // Calculate fee: 1.5% for virtual account
                $fee = ($amount * 1.5) / 100;
                $netAmount = $amount - $fee;

                // Create or update wallet funding record
                $paymentMethodId = \App\Models\PaymentMethod::where('name', 'LIKE', '%Paystack%')->value('id');
                
                $walletFunding = WalletFunding::updateOrCreate(
                    ['reference' => $reference],
                    [
                        'user_id' => $user->id,
                        'payment_method_id' => $paymentMethodId,
                        'amount' => $amount,
                        'fee' => $fee,
                        'status' => 'successful',
                        'response_data' => array_merge($data, [
                            'completed_at' => now(),
                            'fee' => $fee,
                            'net_amount' => $netAmount,
                            'type' => 'dedicated_virtual_account'
                        ]),
                    ]
                );

                // Create or update transaction record
                $transaction = Transaction::updateOrCreate(
                    ['reference' => $reference],
                    [
                        'user_id' => $user->id,
                        'type' => 'wallet_funding',
                        'amount' => $amount,
                        'fee' => $fee,
                        'status' => 'successful',
                        'recipient' => $user->email,
                        'description' => 'Dedicated Virtual Account Funding of ₦' . number_format($amount, 2),
                        'meta_data' => [
                            'payment_method' => 'paystack_virtual_account',
                            'channel' => 'dedicated_nuban',
                            'fee' => $fee,
                            'net_amount' => $netAmount,
                        ],
                    ]
                );

                // Settle outstanding debts first
                $borrowingService = app(\App\Services\BorrowingService::class);
                $remainingAmount = $borrowingService->settleDebts($user, $netAmount);
                
                if ($remainingAmount < $netAmount) {
                    $settledAmount = $netAmount - $remainingAmount;
                    $notificationService = app(\App\Services\NotificationService::class);
                    $notificationService->sendSystemNotification(
                        $user,
                        'Debt Automatically Settled',
                        "₦" . number_format($settledAmount, 2) . " has been deducted from your virtual account funding to settle your outstanding debt.",
                        'info'
                    );
                }
                
                $user->wallet_balance += $remainingAmount;
                $user->save();

                // Process referral bonus
                $referralService = app(\App\Services\ReferralService::class);
                $referralService->processReferralBonus($transaction);

                return [
                    'success' => true,
                    'message' => 'Virtual account funding processed successfully',
                ];
            });
        } catch (\Exception $e) {
            Log::error('Paystack processDedicatedAccountTransaction failed: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'Internal error: ' . $e->getMessage(),
            ];
        } finally {
            $lock->release();
        }
    }

    /**
     * Process card charge
     */
    protected function processCardCharge($reference, $amount, $data)
    {
        // Handle card charge webhook
        // Could be for various purposes - update relevant records
        
        Log::info('Card charge processed', [
            'reference' => $reference,
            'amount' => $amount,
            'data' => $data,
        ]);

        return [
            'success' => true,
            'message' => 'Card charge processed',
        ];
    }

    /**
     * Validate webhook signature
     */
    public function validateWebhookSignature($payload, $signature)
    {
        $computedSignature = hash_hmac('sha512', $payload, $this->secretKey);
        return hash_equals($computedSignature, $signature);
    }

    /**
     * Get banks list for transfers
     */
    public function getBanks()
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->secretKey,
                'Accept' => 'application/json',
            ])->get($this->baseUrl . '/bank');

            if ($response->successful()) {
                return [
                    'success' => true,
                    'data' => $response->json()['data'] ?? [],
                ];
            }

            return [
                'success' => false,
                'message' => 'Failed to fetch banks',
            ];
        } catch (Exception $e) {
            Log::error('Paystack Error: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'An error occurred',
            ];
        }
    }

    /**
     * Create transfer recipient
     */
    public function createTransferRecipient($accountNumber, $bankCode, $name)
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->secretKey,
                'Accept' => 'application/json',
            ])->post($this->baseUrl . '/transferrecipient', [
                'type' => 'nuban',
                'name' => $name,
                'account_number' => $accountNumber,
                'bank_code' => $bankCode,
                'currency' => 'NGN',
            ]);

            if ($response->successful()) {
                return [
                    'success' => true,
                    'data' => $response->json()['data'] ?? [],
                ];
            }

            return [
                'success' => false,
                'message' => 'Failed to create transfer recipient',
            ];
        } catch (Exception $e) {
            Log::error('Paystack Error: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'An error occurred',
            ];
        }
    }

    /**
     * Initiate transfer
     */
    public function initiateTransfer($recipientCode, $amount, $reason)
    {
        try {
            $response = Http::withHeaders([
                'Authorization' => 'Bearer ' . $this->secretKey,
                'Accept' => 'application/json',
            ])->post($this->baseUrl . '/transfer', [
                'source' => 'balance',
                'reason' => $reason,
                'amount' => $amount * 100,
                'recipient' => $recipientCode,
                'reference' => 'TRF_' . time() . '_' . uniqid(),
            ]);

            if ($response->successful()) {
                return [
                    'success' => true,
                    'data' => $response->json()['data'] ?? [],
                ];
            }

            return [
                'success' => false,
                'message' => 'Failed to initiate transfer',
            ];
        } catch (Exception $e) {
            Log::error('Paystack Error: ' . $e->getMessage());
            return [
                'success' => false,
                'message' => 'An error occurred',
            ];
        }
    }
}